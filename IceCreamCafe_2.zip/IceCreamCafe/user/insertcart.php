<?php

session_start();

// Check if the session cart exists, if not initialize it
if(isset($_SESSION['user'])){
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array(); // Initialize cart as an empty array
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['PName']) && isset($_POST['PPrice']) && isset($_POST['PQuantity'])) {
        $product_name = $_POST['PName'];
        $product_price = $_POST['PPrice'];
        $product_quantity = $_POST['PQuantity'];

        // Adding to the cart
        if (isset($_POST['addCart'])) {
            // Check if the product is already in the cart
            $check_product = array_column($_SESSION['cart'], 'productName');
            if (in_array($product_name, $check_product)) {
                echo "
                <script>
                alert('Product already added');
                window.location.href = 'index.php';
                </script>";
            } else {
                // Add new product to the cart
                $_SESSION['cart'][] = array(
                    'productName' => $product_name,
                    'productPrice' => $product_price,
                    'productQuantity' => $product_quantity
                );
                header("location:viewcart.php");
            }
        }
    }

    // Remove product
    if (isset($_POST['remove']) && isset($_POST['item'])) {
        foreach ($_SESSION['cart'] as $key => $value) {
            if ($value['productName'] === $_POST['item']) {
                unset($_SESSION['cart'][$key]);
                $_SESSION['cart'] = array_values($_SESSION['cart']); // Reset array keys
                header('location:viewcart.php');
            }
        }
    }

    // Update product quantity
    if (isset($_POST['update'])) {
        foreach ($_SESSION['cart'] as $key => $value) {
            if ($value['productName'] === $_POST['item']) {
                $_SESSION['cart'][$key] = array(
                    'productName' => $product_name,
                    'productPrice' => $product_price,
                    'productQuantity' => $product_quantity
                );
                header("location:viewcart.php");
            }
        }
    }
}
}
else{
    header("location:form/login.php");
}
?>
