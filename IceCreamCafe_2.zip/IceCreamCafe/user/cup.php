<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home-page</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <?php
    include 'header.php';
    ?>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            
            <h1 class="text-warning font-monospace text-center my-3">CUPS/BUCKETS</h1>

            <?php
            include 'Config.php';
            $Record = mysqli_query($con, "select * from tblproduct");
            while($row = mysqli_fetch_array($Record)){
                $check_page = $row['PCategory'];
                if( $check_page ==='Cup'){
                echo "
                <div class='col-md-4 my-3'>
                <form action = 'insertcart.php' method = 'POST'>
                    <div class='card' style='width: 100%;'>
                        <img src='../admin/product/$row[Pimage]' class='card-img-top' height='300' width='250'>
                        <div class='card-body text-center '>
                            <h5 class='card-title text-danger fs-4 fw-bold'>$row[PName]</h5>
                            <p class='card-text text-danger fs-4 fw-bold'>";?>RS:<?php echo number_format($row['PPrice'],2)?><?php echo "</p>
                             <input type = 'hidden' name = 'PName' value = '$row[PName]'>
                            <input type = 'hidden' name = 'PPrice' value = '$row[PPrice]'>
                            <input type='number' name = 'PQuantity' value =' min '1' max = '20'' placeholder='Quantity'><br><br>
                            <input type='submit' name = 'addCart' class='btn btn-warning text-white w-100' value='Add To Cart'>
                        </div>
                    </div>
                    </form>
                </div>
                ";
            }
        }
            ?>
        </div>
    </div>

    <!-- Bootstrap JS CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <div class="mt-5 fs-5 font-monospace text-center">
        <p class="fixed-bottom text-white bg-danger py-2 mb-0"> just a basic ice_cream_cafe </p>
    </div>
</body>
</html>
