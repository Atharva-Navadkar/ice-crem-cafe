<?php 

// Establish connection to the database
$Con = mysqli_connect('localhost', 'root', '', 'ecommerce');

// Check connection
if (!$Con) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    // Sanitize user input
    $Name = mysqli_real_escape_string($Con, $_POST['name']);
    $Email = mysqli_real_escape_string($Con, $_POST['email']);
    $Number = mysqli_real_escape_string($Con, $_POST['number']);
    $Password = mysqli_real_escape_string($Con, $_POST['password']);  // Store plain text password

    // Check for duplicate Email
    $Dup_Email = mysqli_query($Con, "SELECT * FROM tbluser WHERE Email = '$Email'");
    
    // Check for duplicate Username
    $Dup_Username = mysqli_query($Con, "SELECT * FROM tbluser WHERE UserName = '$Name'");

    if (mysqli_num_rows($Dup_Email) > 0) {
        echo "
        <script>
        alert('This Email is already taken');
        window.location.href = 'register.php';
        </script>";
    } elseif (mysqli_num_rows($Dup_Username) > 0) {
        echo "
        <script>
        alert('This Username is already taken');
        window.location.href = 'register.php';
        </script>";
    } else {
        // Insert the new user into the database with the plain text password
        $stmt = $Con->prepare("INSERT INTO tbluser (UserName, Email, Number, Password) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $Name, $Email, $Number, $Password);

        // Execute the query and check for success
        if ($stmt->execute()) {
            echo "
            <script>
            alert('New user registered successfully!');
            window.location.href = 'login.php'; // Redirect to the login page after successful registration
            </script>";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    }
}

// Close the connection
mysqli_close($Con);

?>

