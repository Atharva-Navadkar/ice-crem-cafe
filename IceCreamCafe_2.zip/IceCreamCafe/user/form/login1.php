<?php

$Name = $_POST['name'];
$Password = $_POST['password'];

// Establish connection to the database
$Con = mysqli_connect('localhost', 'root', '', 'ecommerce');

$result = mysqli_query($Con,"SELECT * FROM tbluser WHERE (Email = '$Name' OR UserName = '$Name') AND Password = '$Password'");

session_start();

if(mysqli_num_rows($result)){

    $_SESSION['user'] = $Name ;



    echo "
    <script>
    alert('Succefully Logged In');
    window.location.href = '../index.php';
    </script>
    ";
}
else{
    echo "
        <script>
        alert('Incorrect Username/Email/Password');
        window.location.href = 'login.php';
        </script> ";

}

?>