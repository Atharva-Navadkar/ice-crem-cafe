<?php
// Config.php
$con = mysqli_connect('localhost', 'root', '', 'ecommerce');

?>
