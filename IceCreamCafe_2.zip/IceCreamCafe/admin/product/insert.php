
<?php

if(isset($_POST['submit'])) {
    include 'Config.php';

    $product_name = $_POST['Pname'];
    $product_price = $_POST['Pprice'];
    $product_image = $_FILES['Pimage'];
    $image_loc = $_FILES['Pimage']['tmp_name'];
    $image_name = $_FILES['Pimage']['name'];
    $img_des = "Uploadimage/" . $image_name;
    
    // Move the uploaded file to the "Uploadimage" folder
    move_uploaded_file($image_loc, $img_des);

    $product_category = $_POST['Pages'];

    // Insert product into the database
    mysqli_query($con, "INSERT INTO `tblproduct`(`PName`, `PPrice`, `Pimage`, `PCategory`) 
        VALUES ('$product_name','$product_price','$img_des','$product_category')");

    // Redirect to index.php after successful upload
    header("Location: index.php");
    exit(); // Ensure no further code is executed
}
?>
